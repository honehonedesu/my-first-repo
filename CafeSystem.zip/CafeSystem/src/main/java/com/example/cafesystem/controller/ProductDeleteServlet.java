package com.example.cafesystem.controller;

import java.io.IOException;

import com.example.cafesystem.dao.ProductDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/product/delete")
public class ProductDeleteServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    ProductDAO dao = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        int productId = Integer.parseInt(request.getParameter("id"));

        dao.delete(productId);

        response.sendRedirect(request.getContextPath() + "/product/list");
    }
}