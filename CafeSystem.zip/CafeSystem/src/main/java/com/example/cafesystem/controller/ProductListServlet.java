package com.example.cafesystem.controller;

import java.io.IOException;
import java.util.List;

import com.example.cafesystem.dao.ProductDAO;
import com.example.cafesystem.model.Product;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/product/list")
public class ProductListServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    ProductDAO dao = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        List<Product> productList = dao.findAll();

        request.setAttribute("productList", productList);

        request.getRequestDispatcher("/WEB-INF/productList.jsp")
        .forward(request, response);
    }
}