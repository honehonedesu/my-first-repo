package com.example.cafesystem.controller;

import java.io.IOException;

import com.example.cafesystem.dao.ProductDAO;
import com.example.cafesystem.model.Product;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/product/register")
public class ProductRegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    ProductDAO dao = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

    	request.getRequestDispatcher("/WEB-INF/productRegister.jsp")
        .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String productName = request.getParameter("productName");
        int price = Integer.parseInt(request.getParameter("price"));
        int stock = Integer.parseInt(request.getParameter("stock"));

        Product product = new Product();
        product.setProductName(productName);
        product.setPrice(price);
        product.setStock(stock);

        System.out.println("登録開始");

        boolean result = dao.insert(product);

        System.out.println("登録結果：" + result);

        if (result) {
            response.sendRedirect(request.getContextPath() + "/product/list");
        } else {
            response.getWriter().println("登録に失敗しました");
        }
    }
}