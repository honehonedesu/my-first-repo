package com.example.cafesystem.controller;

import java.io.IOException;

import com.example.cafesystem.dao.ProductDAO;
import com.example.cafesystem.model.Product;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/product/updateStock")
public class StockUpdateServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    ProductDAO dao = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        int productId = Integer.parseInt(request.getParameter("id"));

        Product product = dao.findById(productId);

        request.setAttribute("product", product);

        request.getRequestDispatcher("/WEB-INF/stockUpdate.jsp")
               .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        int productId = Integer.parseInt(request.getParameter("productId"));
        int stock = Integer.parseInt(request.getParameter("stock"));

        dao.updateStock(productId, stock);

        response.sendRedirect(request.getContextPath() + "/product/list");
    }
}