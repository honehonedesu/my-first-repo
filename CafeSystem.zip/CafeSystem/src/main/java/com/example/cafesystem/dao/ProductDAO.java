package com.example.cafesystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.example.cafesystem.model.Product;
import com.example.cafesystem.util.DBUtil;

public class ProductDAO {

    // 商品登録
	public boolean insert(Product product) {

	    String sql = "INSERT INTO product(product_name, price, stock) VALUES(?,?,?)";

	    try (
	        Connection con = DBUtil.getConnection();
	        PreparedStatement ps = con.prepareStatement(sql)
	    ) {

	        ps.setString(1, product.getProductName());
	        ps.setInt(2, product.getPrice());
	        ps.setInt(3, product.getStock());

	        return ps.executeUpdate() > 0;

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return false;
	}

    // 商品一覧
	public List<Product> findAll() {

	    List<Product> list = new ArrayList<>();

	    String sql = "SELECT * FROM product ORDER BY product_id";

	    try (
	        Connection con = DBUtil.getConnection();
	        PreparedStatement ps = con.prepareStatement(sql);
	        ResultSet rs = ps.executeQuery()
	    ) {

	        while (rs.next()) {

	            Product p = new Product();

	            p.setProductId(rs.getInt("product_id"));
	            p.setProductName(rs.getString("product_name"));
	            p.setPrice(rs.getInt("price"));
	            p.setStock(rs.getInt("stock"));

	            list.add(p);
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return list;
	}

    // 在庫更新
	public boolean updateStock(int productId, int stock) {

	    String sql = "UPDATE product SET stock=? WHERE product_id=?";

	    try (
	        Connection con = DBUtil.getConnection();
	        PreparedStatement ps = con.prepareStatement(sql)
	    ) {

	        ps.setInt(1, stock);
	        ps.setInt(2, productId);

	        return ps.executeUpdate() > 0;

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return false;
	}
	
	public Product findById(int productId) {

	    String sql = "SELECT * FROM product WHERE product_id=?";

	    try (
	        Connection con = DBUtil.getConnection();
	        PreparedStatement ps = con.prepareStatement(sql)
	    ) {

	        ps.setInt(1, productId);

	        ResultSet rs = ps.executeQuery();

	        if(rs.next()){

	            Product product = new Product();

	            product.setProductId(rs.getInt("product_id"));
	            product.setProductName(rs.getString("product_name"));
	            product.setPrice(rs.getInt("price"));
	            product.setStock(rs.getInt("stock"));

	            return product;
	        }

	    } catch(Exception e){
	        e.printStackTrace();
	    }

	    return null;
	}
	
	// 商品削除
	public boolean delete(int productId) {

	    String sql = "DELETE FROM product WHERE product_id=?";

	    try (
	        Connection con = DBUtil.getConnection();
	        PreparedStatement ps = con.prepareStatement(sql)
	    ) {

	        ps.setInt(1, productId);

	        return ps.executeUpdate() > 0;

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return false;
	}

}