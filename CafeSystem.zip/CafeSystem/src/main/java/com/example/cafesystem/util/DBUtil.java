package com.example.cafesystem.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {

    // PostgreSQL接続情報
    private static final String URL = "jdbc:postgresql://localhost:5432/cafesystem";
    private static final String USER = "postgres";
    private static final String PASSWORD = "post";

    // データベース接続
    public static Connection getConnection() throws SQLException {

        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}