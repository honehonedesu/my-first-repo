<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List"%>
<%@ page import="com.example.cafesystem.model.Product"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>商品一覧</title>

<style>
body{
    font-family: Arial;
    background:#f5f5f5;
}

.container{
    width:800px;
    margin:auto;
}

table{
    width:100%;
    border-collapse:collapse;
    background:white;
}

th,td{
    border:1px solid #ccc;
    padding:10px;
    text-align:center;
}

th{
    background:#4CAF50;
    color:white;
}

h2{
    text-align:center;
}

a.button{
    display:inline-block;
    margin:15px 0;
    padding:10px 15px;
    background:#4CAF50;
    color:white;
    text-decoration:none;
    border-radius:5px;
}
</style>

</head>
<body>

<div class="container">

<h2>商品一覧</h2>

<a class="button"
href="${pageContext.request.contextPath}/product/register">
商品登録
</a>

<table>

<tr>
    <th>ID</th>
    <th>商品名</th>
    <th>価格</th>
    <th>在庫</th>
    <th>操作</th>
</tr>

<%
List<Product> list = (List<Product>)request.getAttribute("productList");

if(list != null){
    for(Product p : list){
%>

<tr>

<td><%=p.getProductId()%></td>
<td><%=p.getProductName()%></td>
<td>¥<%=p.getPrice()%></td>
<td><%=p.getStock()%></td>

<td>

<a href="${pageContext.request.contextPath}/product/updateStock?id=<%=p.getProductId()%>">
更新
</a>

|

<a href="${pageContext.request.contextPath}/product/delete?id=<%=p.getProductId()%>"
   onclick="return confirm('この商品を削除しますか？');">
削除
</a>

</td>

</tr>

<%
    }
}
%>

</table>

</div>

</body>
</html>