<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>商品登録</title>

<style>
body{
    font-family: sans-serif;
    background:#f5f5f5;
}

.container{
    width:450px;
    margin:50px auto;
    background:white;
    padding:30px;
    border-radius:10px;
    box-shadow:0 0 10px gray;
}

h2{
    text-align:center;
}

table{
    width:100%;
}

td{
    padding:10px;
}

input[type=text],
input[type=number]{
    width:100%;
    padding:8px;
}

button{
    width:100%;
    padding:10px;
    background:#4CAF50;
    color:white;
    border:none;
    border-radius:5px;
    cursor:pointer;
}

button:hover{
    background:#45a049;
}
</style>

</head>
<body>

<div class="container">

<h2>商品登録</h2>

<form action="${pageContext.request.contextPath}/product/register" method="post">

<table>

<tr>
<td>商品名</td>
<td>
<input type="text"
       name="productName"
       required>
</td>
</tr>

<tr>
<td>価格</td>
<td>
<input type="number"
       name="price"
       min="0"
       required>
</td>
</tr>

<tr>
<td>在庫数</td>
<td>
<input type="number"
       name="stock"
       min="0"
       required>
</td>
</tr>

<tr>
<td colspan="2">
<button type="submit">
登録
</button>
</td>
</tr>

</table>

</form>

</div>

</body>
</html>