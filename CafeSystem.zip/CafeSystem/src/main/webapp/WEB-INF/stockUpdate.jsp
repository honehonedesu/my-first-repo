<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.example.cafesystem.model.Product"%>

<%
Product product = (Product)request.getAttribute("product");
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>在庫更新</title>

<style>
body{
    font-family:sans-serif;
    background:#f5f5f5;
}

.container{
    width:400px;
    margin:50px auto;
    background:white;
    padding:30px;
    border-radius:10px;
    box-shadow:0 0 10px gray;
}

table{
    width:100%;
}

td{
    padding:10px;
}

input[type=number]{
    width:100%;
    padding:8px;
}

button{
    width:100%;
    padding:10px;
    background:#4CAF50;
    color:white;
    border:none;
    border-radius:5px;
    cursor:pointer;
}
</style>

</head>
<body>

<div class="container">

<h2>在庫更新</h2>

<form action="${pageContext.request.contextPath}/product/updateStock" method="post">

<input type="hidden"
       name="productId"
       value="<%=product.getProductId()%>">

<table>

<tr>
<td>商品名</td>
<td><%=product.getProductName()%></td>
</tr>

<tr>
<td>価格</td>
<td>¥<%=product.getPrice()%></td>
</tr>

<tr>
<td>現在の在庫</td>
<td><%=product.getStock()%></td>
</tr>

<tr>
<td>新しい在庫</td>
<td>
<input type="number"
       name="stock"
       value="<%=product.getStock()%>"
       min="0">
</td>
</tr>

<tr>
<td colspan="2">
<button type="submit">更新</button>
</td>
</tr>

</table>

</form>

</div>

</body>
</html>